<div class="head">
          <div class="ham-name">
            <div class="mnu vy" onclick="hide()" id="mn">
              <span></span>
              <span></span>
              <span></span>
            </div>
            <div class="mnu ty" onclick="op_n()" id="mn">
              <span></span>
              <span></span>
              <span></span>
            </div>
            <div class="nm">Dashbord</div>
          </div>
          <div class="profile">
            <a href="javascript:void(0)">
              <img src="assets/images/pic1.jpg" alt="" />
            </a>
            <div class="name">
              <span>jhon</span>
              <small>Delivery</small>
            </div>
            <div class="hover-bot">
              <ul>
                <li>
                  <a href="javascript:void(0)" onclick="logout()">
                    <i class="uil uil-sign-out-alt"></i>
                    <span>Logout</span>
                  </a>
                </li>
                <li style="opacity:0">
                  <a href="">
                    <i class="uil uil-user"></i>
                    <span>Profile</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>